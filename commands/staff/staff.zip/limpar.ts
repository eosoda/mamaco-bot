import DiscordJS, { MessageEmbed } from 'discord.js'
import { ICommand } from 'wokcommands'
import ms from 'ms'

export default {
  category: 'staff',
  description: 'Limpa Mensagens',
  slash: true,
  maxArgs: 1,
  requiredPermissions: ['MANAGE_MESSAGES'],
  options: [
    {
      name: 'amount',
      description: 'Quantidade de mensagens para deletar.',
      required: true,
      type: DiscordJS.Constants.ApplicationCommandOptionTypes.INTEGER,
    },
  ],
  callback: async ({ args, message, interaction, channel }) => {
    const amount = interaction.options.getInteger('amount')

    // @ts-ignore: Object is possibly 'null'.
    if (amount > 100) {
      return interaction.reply({
        content: 'Só consigo deletar até 100 mensagens',
      })
    }
    const messages = await interaction.channel?.messages.fetch({
      // @ts-ignore: Object is possibly 'null'.
      limit: amount + 1,
    })
    // @ts-ignore: Object is possibly 'null'.
    const filtered = messages.filter(
      (msg) => Date.now() - msg.createdTimestamp < ms('14 days')
    )

    await channel.bulkDelete(filtered)

    interaction.channel
      ?.send({ content: `${filtered.size - 1} deletadas` })
      .then((msg) => {
        setTimeout(() => {
          msg.delete()
        }, ms('5 seconds'))
      })
  },
} as ICommand
