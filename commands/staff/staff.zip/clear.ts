import { ICommand } from 'wokcommands'

export default {
  category: 'staff',
  description: 'Limpa Mensagens',
  name: 'clear',
  slash: false,
  expectedArgs: '<qtd>',
  maxArgs: 1,
  requiredPermissions: ['MANAGE_MESSAGES'],
  callback: async ({ message, args, channel }) => {
    const delamount = parseInt(args[0])
    if (delamount > 99) {
      return message.reply('Só consigo deletar no máximo 99 mensagens')
    }
    await channel.bulkDelete(delamount + 1)
    message.channel
      .send(`Deletei ${delamount} mensagens`)
      .then((msg) => msg.delete())
  },
} as ICommand
